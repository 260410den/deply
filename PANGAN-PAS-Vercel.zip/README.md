# PANGAN PAS

Prototype dashboard untuk melihat simulasi perubahan harga pangan antarprovinsi di Indonesia. Peta memakai MapLibre dengan data batas provinsi lokal; harga dan tren yang tampil merupakan data simulasi.

## Menjalankan lokal

```bash
npm install
```

Salin `.env.example` menjadi `.env.local`, lalu isi `NVIDIA_API_KEY` untuk mengaktifkan asisten AI. Jangan commit `.env.local` atau membagikan API key di repository publik.

```bash
npm run dev
```

## Build

```bash
npm run build
```

## Stack

- React dan Vite
- MapLibre GL JS dengan OpenFreeMap
- Recharts
- NVIDIA chat completions API untuk asisten pangan

## Deploy ke Vercel

Folder ini sudah dikonfigurasi untuk Vercel sebagai aplikasi Vite SPA. Hubungkan repository/folder ke Vercel atau jalankan `npx vercel` dari folder proyek. Untuk production gunakan `npx vercel --prod`.

Build command: `npm run build`  
Output directory: `dist`

Agar Asisten Pangan aktif setelah deploy, tambahkan environment variable `NVIDIA_API_KEY` di Vercel Project Settings → Environment Variables. Jangan masukkan key ke file frontend atau commit `.env.local`. Endpoint AI berada di `api/ai.js` dan meneruskan jawaban secara streaming.
