const { Readable } = require('node:stream');

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.NVIDIA_API_KEY;
  if (!apiKey) {
    return res.status(503).json({ error: 'Asisten AI belum dikonfigurasi di server.' });
  }

  const payload = req.body;
  if (!payload || !Array.isArray(payload.messages) || payload.messages.length > 12) {
    return res.status(400).json({ error: 'Format percakapan tidak valid.' });
  }

  const body = {
    model: 'nvidia/nemotron-3.5-lightning-30b-a3b',
    messages: payload.messages,
    temperature: 0.2,
    max_tokens: 140,
    chat_template_kwargs: { enable_thinking: false },
    stream: true,
  };

  try {
    const upstream = await fetch('https://integrate.api.nvidia.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (!upstream.ok) {
      const detail = await upstream.text();
      return res.status(upstream.status).json({ error: detail.slice(0, 1200) });
    }

    if (!upstream.body) {
      return res.status(502).json({ error: 'Stream dari layanan AI tidak tersedia.' });
    }

    res.status(200);
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    Readable.fromWeb(upstream.body).pipe(res);
  } catch {
    if (!res.headersSent) {
      return res.status(502).json({ error: 'Layanan AI sedang tidak bisa dihubungi.' });
    }
    res.end();
  }
};
